package Utility;

import java.util.Map;

import Assignment.ModularBankTest;

import java.util.HashMap;
public class HeaderConfigs {
	
	public static Map<String, String> defaultHeaders() {
		
		
		Map<String,String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type","application/json");
		headerMap.put("x-tenant-code", "SANDBOX");
		headerMap.put("x-channel-code", "SYSTEM");
		return headerMap;
		
	}
	

public static Map<String, String> defaultHeaderswithJWTToken() {
		
		
		Map<String,String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type","application/json");
		headerMap.put("x-tenant-code", "SANDBOX");
		headerMap.put("x-channel-code", "SYSTEM");
		headerMap.put("x-auth-token", ModularBankTest.jwtToken);
        return headerMap;
		
	}
	
	
	}
	
	


