package Files;

public class payload {
	
	
	public static String getJWTToken() {
		
		
		return "{\r\n"
				+ "\"username\": \"modular.system\",\r\n"
				+ "\"password\": \"pass\"\r\n"
				+ "}";
		
	}

	
	public static String createCustomers() {
		
		
		return "\"givenName\": \"Peter\",\r\n"
				+ "\"surname\": \"Schmidt\",\r\n"
				+ "\"middleName\": \"Alexander\",\r\n"
				+ "\"birthDate\": \"1980-12-01\",\r\n"
				+ "\"personTypeCode\": \"P\",\r\n"
				+ "\"sex\": \"M\",\r\n"
				+ "\"email\": \"psmidt@smidt.de\",\r\n"
				+ "\"phoneNumber\": \"0901820\",\r\n"
				+ "\"phoneCountryCode\": \"+372\",\r\n"
				+ "\"educationCode\": \"HIGHER_EDUCATION\",\r\n"
				+ "\"activityCode\": \"SPECIALIST\",\r\n"
				+ "\"housingTypeCode\": \"PRIVATE\",\r\n"
				+ "\"buildingTypeCode\": \"APARTMENT\",\r\n"
				+ "\"businessAreaCode\": \"LEGAL\",\r\n"
				+ "\"maritalStatusCode\": \"MARRIED\",\r\n"
				+ "\"dependantPersons\": 1,\r\n"
				+ "\"employmentTimeCode\": \"MORE_4_YEAR\",\r\n"
				+ "\"customerType\": \"string\",\r\n"
				+ "\"nationality\": \"DE\",\r\n"
				+ "\"placeOfBirth\": \"Berlin\",\r\n"
				+ "\"countryOfBirth\": \"DE\",\r\n"
				+ "\"language\": \"DE\",\r\n"
				+ "\"taxResidencyCountry\": \"DE\",\r\n"
				+ "\"fixedEmploymentLength\": 6,\r\n"
				+ "\"identificationNumber\": {\r\n"
				+ "\"idNumber\": \"12123456A1\",\r\n"
				+ "\"idCountryCode\": \"DE\",\r\n"
				+ "\"vatNumber\": \"DE123456789\",\r\n"
				+ "\"taxNumber\": \"12345678901\"\r\n"
				+ "},\r\n"
				+ "\"addresses\": [\r\n"
				+ "{\r\n"
				+ "\"addressTypeCode\": \"R\",\r\n"
				+ "\"street1\": \"Fennstrasse 4\",\r\n"
				+ "\"street2\": \"string\",\r\n"
				+ "\"cityCounty\": \"Berlin\",\r\n"
				+ "\"stateRegion\": \"Berlin\",\r\n"
				+ "\"zip\": \"13347\",\r\n"
				+ "\"countryCode\": \"DE\",\r\n"
				+ "\"moveInDate\": \"2018-06-23\"\r\n"
				+ "}\r\n"
				+ "],\r\n"
				+ "\"document\": {\r\n"
				+ "\"issuingCountry\": \"DE\",\r\n"
				+ "\"number\": \"0124R5M1P7\",\r\n"
				+ "\"documentTypeCode\": \"PASSPORT\",\r\n"
				+ "\"expiryDate\": \"2025-01-03\"\r\n"
				+ "},\r\n"
				+ "\"usResident\": true,\r\n"
				+ "\"pep\": true\r\n"
				+ "}";
	}
	
	
	public static String createTransactions() {
		
		return "{\r\n"
				+ "\"details\": \"Card topup\",\r\n"
				+ "\"effectiveDate\": \"2020-06-08\",\r\n"
				+ "\"money\": {\r\n"
				+ "\"amount\": 238,\r\n"
				+ "\"currencyCode\": \"EUR\"\r\n"
				+ "},\r\n"
				+ "\"source\": {\r\n"
				+ "\"sourceName\": \"CARD_TOPUP\",\r\n"
				+ "\"sourceRef\": \"ID-{{$timestamp}}\"\r\n"
				+ "},\r\n"
				+ "\"transactionTypeCode\": \"CARD_TOPUP\"\r\n"
				+ "}";
		
		
	}
	
	public static String createPayments() {
		
		return "{\r\n"
				+ "\"counterparty\": {\r\n"
				+ "\"counterpartyTypeCode\": \"IBAN\",\r\n"
				+ "\"name\": \"Ben Ficher\",\r\n"
				+ "\"value\": \"EE459999000000010140\"\r\n"
				+ "},\r\n"
				+ "\"details\": \"Details\",\r\n"
				+ "\"directionCode\": \"OUT\",\r\n"
				+ "\"effectiveDate\": \"2020-06-08\",\r\n"
				+ "\"endToEndId\": \"NOTPROVIDED\",\r\n"
				+ "\"money\": {\r\n"
				+ "\"amount\": 24.35,\r\n"
				+ "\"currencyCode\": \"EUR\"\r\n"
				+ "},\r\n"
				+ "\"paymentTransferTypeCode\": \"INSTANTREGULAR\",\r\n"
				+ "\"paymentTypeCode\": \"ACC2SEPA\",\r\n"
				+ "\"source\": {\r\n"
				+ "\"sourceName\": \"PAYMENT\",\r\n"
				+ "\"sourceRef\": \"ID-{{$timestamp}}\"\r\n"
				+ "}\r\n"
				+ "}\r\n"
				+ "";
		
	}
	
	
	
}
