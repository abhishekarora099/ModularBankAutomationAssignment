package Assignment;
import static io.restassured.RestAssured.*;

import org.testng.annotations.Test;

import Files.payload;
import Utility.HeaderConfigs;
import io.restassured.path.json.JsonPath;
public class ModularBankTest {

	String jwtTokenResponse;
	JsonPath js;
	public static String jwtToken;
	String personIdResponse;
	String personId1;
	String AccountIdResponse;
	String AccountId;
	String TransactionsResponse;
	String PaymentsIdResponse;
	String PaymentId;
	String AccountStatementResponse;
	
	@Test(priority=0)
	public void Authentication() {
		// TODO Auto-generated method stub

		
		jwtTokenResponse= given().log().all()
				.headers(HeaderConfigs.defaultHeaders()).body(payload.getJWTToken()).when().post("https://auth-api.sandbox.modularbank.xyz/api/v1/employees/authorise").asString();
		
		js= new JsonPath(jwtTokenResponse);
		jwtToken= js.getString("data.token");
		System.out.println(jwtToken);
		
		
		
		
		
		
	}
	
	@Test(priority=1)
	public void CreateCustomers() {
		
		personIdResponse=given().log().all()
		.headers(HeaderConfigs.defaultHeaderswithJWTToken()).header("Authorization","Bearer "+jwtToken).body(payload.createCustomers()).when().post("https://person-api.sandbox.modularbank.xyz/api/v1/persons").asString();

		js= new JsonPath(personIdResponse);
		personId1=js.getString("data.values[0].personId");
		System.out.println(personId1);
		
		
	}
	
	
	@Test(priority=2)
	
	public void CreateAccount() {
		
		AccountIdResponse=given().log().all().pathParam("personId", personId1)
				.headers(HeaderConfigs.defaultHeaderswithJWTToken()).when().get("https://account-api.sandbox.modularbank.xyz/api/v1/persons/{personId}/accounts").asString();
		
		js= new JsonPath(AccountIdResponse);
		AccountId=js.getString("data.accountId");
		System.out.println(AccountId);
		

		given().log().all().pathParam("accountId", AccountId).headers(HeaderConfigs.defaultHeaderswithJWTToken()).when().get("https://account-api.sandbox.modularbank.xyz/api/v1/accounts/{accountId}").then().log().all().assertThat().statusCode(200);
	}
	
	
	@Test(priority=3)
	
	public void CreateTransactions() {
		
		TransactionsResponse=given().log().all().pathParam("accountId", AccountId)
				.headers(HeaderConfigs.defaultHeaderswithJWTToken()).body(payload.createTransactions()).when().post("https://account-api.sandbox.modularbank.xyz/api/v3/accounts/{accountId}/transactions").asString();
		
		System.out.println(TransactionsResponse);
		
	}
	
	
@Test(priority=4)
	
	public void CreatePayments() {
		
		PaymentsIdResponse=given().log().all().pathParam("accountId", AccountId)
				.headers(HeaderConfigs.defaultHeaderswithJWTToken()).body(payload.createPayments()).when().post("https://account-api.sandbox.modularbank.xyz/api/v1/accounts/{accountId}/payments/initialise").asString();
		
		
		js= new JsonPath(PaymentsIdResponse);
		PaymentId=js.getString("data.paymentId");
		System.out.println(PaymentId);
		
		given().log().all().pathParam("accountId", AccountId).pathParam("paymentId","PaymentId").headers(HeaderConfigs.defaultHeaderswithJWTToken()).when().get("https://account-api.sandbox.modularbank.xyz/api/v1/accounts/{accountId}/payments/{paymentId}/confirm").then().log().all().assertThat().statusCode(200);
	}
	
@Test(priority=5)

public void GetAccountStatement() {
	
	AccountStatementResponse=given().log().all().pathParam("accountId", AccountId)
			.headers(HeaderConfigs.defaultHeaderswithJWTToken()).when().get("https://account-api.sandbox.modularbank.xyz/api/v3/accounts/{accountId}/transactions/search").asString();
	System.out.println(AccountStatementResponse);
	
}




}